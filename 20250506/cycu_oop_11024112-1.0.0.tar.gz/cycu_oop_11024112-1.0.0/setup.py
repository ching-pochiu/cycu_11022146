from setuptools import setup, find_packages

setup(
    name="cycu_oop_11024112",
    version="1.0.0",
    author="Your Name",
    author_email="your_email@example.com",
    description="A package for 20250506 project",
    packages=find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires='>=3.6',
    install_requires=[
        # List your dependencies here, e.g.:
        # "numpy>=1.21.0",
    ],
)
